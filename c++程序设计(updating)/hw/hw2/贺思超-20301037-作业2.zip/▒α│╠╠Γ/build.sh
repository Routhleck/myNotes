sudo g++ test.cc -o test
./test