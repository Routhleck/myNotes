chmod a+x build.sh 给予build.sh可执行权限

./build.sh 执行

运行截图如下

![image-20221027174437316](C:\Users\13107\AppData\Roaming\Typora\typora-user-images\image-20221027174437316.png)