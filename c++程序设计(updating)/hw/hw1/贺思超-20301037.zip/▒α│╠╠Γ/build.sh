g++ -c hw1.cc
g++ hw1.o -o hw1
./hw1

